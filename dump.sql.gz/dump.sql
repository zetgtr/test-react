--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: table; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."table" (
    id integer NOT NULL,
    date date,
    name character(20),
    quantity integer,
    distance integer
);


ALTER TABLE public."table" OWNER TO postgres;

--
-- Name: table_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.table_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.table_id_seq OWNER TO postgres;

--
-- Name: table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.table_id_seq OWNED BY public."table".id;


--
-- Name: table id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."table" ALTER COLUMN id SET DEFAULT nextval('public.table_id_seq'::regclass);


--
-- Data for Name: table; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."table" (id, date, name, quantity, distance) FROM stdin;
26	2020-06-15	Полет               	3	20
1	2020-01-10	Бег                 	1	5
3	2016-11-18	Ходьба              	2	14
4	2011-11-04	Бег                 	4	25
6	2019-11-17	Ходьба              	2	22
8	2018-11-04	Полет               	2	1
11	2015-02-03	Ходьба              	1	12
18	2015-06-08	Полет               	1	5
19	2012-06-19	Бег                 	1	42
21	2013-08-23	Полет               	3	9
23	2010-04-29	Езда                	4	37
24	2011-02-14	Ходьба              	2	39
25	2010-02-11	Полет               	1	11
27	2015-07-25	Бег                 	1	17
29	2021-03-10	Езда                	4	5
36	2010-02-12	Полет               	2	49
37	2010-06-13	Ходьба              	2	38
41	2010-05-13	Полет               	1	7
34	2015-06-25	Плаванье            	4	16
10	2019-06-12	Бег                 	1	49
12	2021-02-03	Плаванье            	4	28
15	2011-09-07	Плаванье            	3	32
47	2015-11-07	Ходьба              	2	2
17	2016-04-01	Плаванье            	1	8
42	2018-08-27	Плаванье            	3	9
50	2014-07-28	Полет               	3	10
49	2016-10-12	Езда                	4	31
46	2011-07-06	Плаванье            	1	14
44	2019-08-28	Езда                	2	42
48	2010-10-18	Плаванье            	1	27
45	2013-06-20	Полет               	2	36
13	2020-08-12	Ходьба              	1	13
28	2016-07-26	Бег                 	2	19
43	2021-03-08	Плаванье            	4	4
39	2021-04-25	Ходьба              	3	10
16	2010-07-16	Полет               	3	2
2	2018-03-14	Плаванье            	3	35
22	2017-08-13	Бег                 	4	37
7	2012-05-11	Ходьба              	2	2
5	2011-08-11	Плаванье            	2	13
38	2020-02-28	Ходьба              	2	4
9	2013-10-28	Полет               	3	40
31	2021-11-08	Плаванье            	4	34
40	2015-06-09	Езда                	1	18
33	2015-11-09	Плаванье            	1	14
32	2017-10-27	Езда                	2	5
14	2021-03-20	Полет               	2	34
20	2016-11-07	Плаванье            	1	22
35	2013-06-01	Езда                	4	14
30	2021-05-22	Плаванье            	2	12
\.


--
-- Name: table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.table_id_seq', 51, true);


--
-- Name: table table_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."table"
    ADD CONSTRAINT table_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

